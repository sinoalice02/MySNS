package com.example;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

// Apache Commons FileUpload 라이브러리를 사용하기 위한 import
import org.apache.commons.fileupload.*;
import org.apache.commons.fileupload.disk.*;
import org.apache.commons.fileupload.servlet.*;

@WebServlet("/uploadFile")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class UploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 디렉토리 경로 설정
        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        try {
            // 파일 업로드 처리
            for (Part part : request.getParts()) {
                String fileName = extractFileName(part);
                part.write(uploadPath + File.separator + fileName);
            }
            request.setAttribute("message", "파일 업로드 성공!");
        } catch (Exception ex) {
            request.setAttribute("message", "파일 업로드 실패: " + ex.getMessage());
        }
        getServletContext().getRequestDispatcher("/result.jsp").forward(request, response);
    }

    // 업로드된 파일 이름 추출
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}
